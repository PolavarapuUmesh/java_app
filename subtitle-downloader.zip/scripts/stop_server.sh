pwd
ls
sudo systemctl stop tomcat
